create table sys_dict
(
    dict_id     bigint auto_increment comment 'ID'
        primary key,
    name        varchar(255) not null comment '字典名称',
    description varchar(255) null comment '描述',
    create_by   varchar(255) null comment '创建者',
    update_by   varchar(255) null comment '更新者',
    create_time datetime     null comment '创建日期',
    update_time datetime     null comment '更新时间'
)
    comment '数据字典' row_format = COMPACT;

INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (1, 'user_status', '用户状态', null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (4, 'dept_status', '部门状态', null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (5, 'job_status', '岗位状态', null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (7, 'bus_order_status', '订单状态', 'admin', 'admin', '2024-10-08 22:42:04', '2024-10-08 22:42:04');
INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (9, 'bus_appName', '平台名称', 'admin', 'admin', '2024-10-09 19:48:25', '2024-10-09 19:48:25');
INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (10, 'bus_category_type', '交易类别', 'admin', 'admin', '2024-11-01 22:54:23', '2024-11-01 23:02:11');
INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (11, 'bus_money_status', '收支状态', 'admin', 'admin', '2024-11-01 23:01:19', '2024-11-01 23:02:01');
INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (12, 'bus_id_type', '账号类型', 'admin', 'admin', '2024-11-01 23:13:01', '2024-11-01 23:13:01');
INSERT INTO eladmin.sys_dict (dict_id, name, description, create_by, update_by, create_time, update_time) VALUES (13, 'bus_upload', '上传选择', 'admin', 'admin', '2024-11-04 00:09:31', '2024-11-04 00:11:26');
