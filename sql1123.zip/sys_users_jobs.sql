create table sys_users_jobs
(
    user_id bigint not null comment '用户ID',
    job_id  bigint not null comment '岗位ID',
    primary key (user_id, job_id)
)
    collate = utf8mb3_uca1400_ai_ci;

INSERT INTO eladmin.sys_users_jobs (user_id, job_id) VALUES (1, 11);
INSERT INTO eladmin.sys_users_jobs (user_id, job_id) VALUES (2, 12);
INSERT INTO eladmin.sys_users_jobs (user_id, job_id) VALUES (3, 10);
INSERT INTO eladmin.sys_users_jobs (user_id, job_id) VALUES (4, 10);
INSERT INTO eladmin.sys_users_jobs (user_id, job_id) VALUES (5, 8);
