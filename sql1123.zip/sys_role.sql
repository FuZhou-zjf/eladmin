create table sys_role
(
    role_id     bigint auto_increment comment 'ID'
        primary key,
    name        varchar(100) not null comment '名称',
    level       int(50)      null comment '角色级别',
    description varchar(255) null comment '描述',
    data_scope  varchar(255) null comment '数据权限',
    create_by   varchar(255) null comment '创建者',
    update_by   varchar(255) null comment '更新者',
    create_time datetime     null comment '创建日期',
    update_time datetime     null comment '更新时间',
    constraint uniq_name
        unique (name)
)
    comment '角色表' row_format = COMPACT;

create index role_name_index
    on sys_role (name);

INSERT INTO eladmin.sys_role (role_id, name, level, description, data_scope, create_by, update_by, create_time, update_time) VALUES (1, '超级管理员', 1, '-', '全部', null, 'admin', '2018-11-23 11:04:37', '2024-11-01 22:36:51');
INSERT INTO eladmin.sys_role (role_id, name, level, description, data_scope, create_by, update_by, create_time, update_time) VALUES (2, '普通用户', 2, '-', '本级', null, 'admin', '2018-11-23 13:09:06', '2024-11-20 23:40:19');
