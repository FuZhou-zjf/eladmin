create table sys_dict_detail
(
    detail_id   bigint auto_increment comment 'ID'
        primary key,
    dict_id     bigint(11)   null comment '字典id',
    label       varchar(255) not null comment '字典标签',
    value       varchar(255) not null comment '字典值',
    dict_sort   int(5)       null comment '排序',
    create_by   varchar(255) null comment '创建者',
    update_by   varchar(255) null comment '更新者',
    create_time datetime     null comment '创建日期',
    update_time datetime     null comment '更新时间'
)
    comment '数据字典详情' row_format = COMPACT;

create index FK5tpkputc6d9nboxojdbgnpmyb
    on sys_dict_detail (dict_id);

INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (1, 1, '激活', 'true', 1, null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (2, 1, '禁用', 'false', 2, null, null, null, null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (3, 4, '启用', 'true', 1, null, null, null, null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (4, 4, '停用', 'false', 2, null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (5, 5, '启用', 'true', 1, null, null, null, null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (6, 5, '停用', 'false', 2, null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (10, 7, '激活', '2', 2, 'admin', 'admin', '2024-10-08 23:19:35', '2024-10-08 23:39:18');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (11, 7, '未激活', '1', 1, 'admin', 'admin', '2024-10-08 23:20:11', '2024-10-08 23:39:14');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (12, 7, '密码找回', '10', 10, 'admin', 'admin', '2024-10-08 23:21:37', '2024-10-08 23:21:37');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (13, 7, '已注册', '3', 3, 'admin', 'admin', '2024-10-08 23:22:13', '2024-10-08 23:22:13');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (14, 7, '未注册', '4', 4, 'admin', 'admin', '2024-10-08 23:22:40', '2024-10-08 23:22:40');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (15, 7, '待处理', '0', 0, 'admin', 'admin', '2024-10-08 23:38:57', '2024-10-08 23:40:33');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (20, 9, '待定', '0', 0, 'admin', 'admin', '2024-10-09 19:49:20', '2024-10-09 19:49:20');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (21, 9, '抖音', '1', 1, 'admin', 'admin', '2024-10-09 19:49:27', '2024-10-09 19:49:27');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (22, 9, '亚马逊', '2', 2, 'admin', 'admin', '2024-10-09 20:36:08', '2024-10-09 20:36:08');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (23, 9, 'eBay', '3', 3, 'admin', 'admin', '2024-10-09 20:36:20', '2024-10-09 20:36:20');
