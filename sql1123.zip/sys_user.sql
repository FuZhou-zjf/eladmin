create table sys_user
(
    user_id        bigint auto_increment comment 'ID'
        primary key,
    dept_id        bigint           null comment '部门名称',
    username       varchar(180)     null comment '用户名',
    nick_name      varchar(255)     null comment '昵称',
    gender         varchar(2)       null comment '性别',
    phone          varchar(255)     null comment '手机号码',
    email          varchar(180)     null comment '邮箱',
    avatar_name    varchar(255)     null comment '头像地址',
    avatar_path    varchar(255)     null comment '头像真实路径',
    password       varchar(255)     null comment '密码',
    is_admin       bit default b'0' null comment '是否为admin账号',
    enabled        bit              null comment '状态：1启用、0禁用',
    create_by      varchar(255)     null comment '创建者',
    update_by      varchar(255)     null comment '更新者',
    pwd_reset_time datetime         null comment '修改密码的时间',
    create_time    datetime         null comment '创建日期',
    update_time    datetime         null comment '更新时间',
    constraint UK_kpubos9gc2cvtkb0thktkbkes
        unique (email),
    constraint uniq_email
        unique (email),
    constraint uniq_username
        unique (username),
    constraint username
        unique (username)
)
    comment '系统用户' row_format = COMPACT;

create index FK5rwmryny6jthaaxkogownknqp
    on sys_user (dept_id);

create index inx_enabled
    on sys_user (enabled);

INSERT INTO eladmin.sys_user (user_id, dept_id, username, nick_name, gender, phone, email, avatar_name, avatar_path, password, is_admin, enabled, create_by, update_by, pwd_reset_time, create_time, update_time) VALUES (1, 7, 'admin', '管理员', '男', '18888888888', '201507802@qq.com', 'avatar-20241117113835411.png', 'C:\\eladmin\\avatar\\avatar-20241117113835411.png', '$2a$10$Egp1/gvFlt7zhlXVfEFw4OfWQCGPw0ClmMcc6FjTnvXNRVf9zdMRa', true, true, null, 'admin', '2020-05-03 16:38:31', '2018-08-23 09:11:56', '2024-11-17 23:38:35');
INSERT INTO eladmin.sys_user (user_id, dept_id, username, nick_name, gender, phone, email, avatar_name, avatar_path, password, is_admin, enabled, create_by, update_by, pwd_reset_time, create_time, update_time) VALUES (2, 8, 'test', '测试', '男', '19999999999', '231@qq.com', null, null, '$2a$10$4XcyudOYTSz6fue6KFNMHeUQnCX5jbBQypLEnGk1PmekXt5c95JcK', false, true, 'admin', 'admin', null, '2020-05-05 11:15:49', '2024-10-10 21:57:47');
INSERT INTO eladmin.sys_user (user_id, dept_id, username, nick_name, gender, phone, email, avatar_name, avatar_path, password, is_admin, enabled, create_by, update_by, pwd_reset_time, create_time, update_time) VALUES (3, 8, 'test01', '打工1号', '男', '18888888861', '123@qq.com', null, null, '$2a$10$DNgkvPGdTGIQfm5HYFxwMuOZlxzDFVqBMXlN2EYVXMSnnDCD8tH82', false, true, 'admin', 'admin', null, '2024-10-04 11:40:40', '2024-10-10 21:57:41');
INSERT INTO eladmin.sys_user (user_id, dept_id, username, nick_name, gender, phone, email, avatar_name, avatar_path, password, is_admin, enabled, create_by, update_by, pwd_reset_time, create_time, update_time) VALUES (4, 6, 'test02', '华北测试打工仔01', '男', '18652020001', 'bei@qq.com', null, null, '$2a$10$baE2cFMNMoW4geiaTmP5MOi6VBu9Eq/1nGcHwp.JnlhMMYq9X9JbO', false, true, 'admin', 'admin', null, '2024-10-10 21:41:12', '2024-10-10 21:59:09');
INSERT INTO eladmin.sys_user (user_id, dept_id, username, nick_name, gender, phone, email, avatar_name, avatar_path, password, is_admin, enabled, create_by, update_by, pwd_reset_time, create_time, update_time) VALUES (5, 7, 'test03', '华南分部打工01', '男', '18188889999', '323@qq.com', 'avatar-20241004112239196.png', 'C:\\eladmin\\avatar\\avatar-20241004112239196.png', '$2a$10$ngjNyLYMBkuLPvdqbXJBBu7FA97toafChPTs3D2Y7snix4Tl.7u.S', false, true, 'admin', 'admin', '2020-05-03 16:38:31', '2024-10-10 21:44:09', '2024-11-20 22:50:41');
