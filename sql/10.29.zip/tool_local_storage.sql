create table tool_local_storage
(
    storage_id  bigint auto_increment comment 'ID'
        primary key,
    real_name   varchar(255) null comment '文件真实的名称',
    name        varchar(255) null comment '文件名',
    suffix      varchar(255) null comment '后缀',
    path        varchar(255) null comment '路径',
    type        varchar(255) null comment '类型',
    size        varchar(100) null comment '大小',
    create_by   varchar(255) null comment '创建者',
    update_by   varchar(255) null comment '更新者',
    create_time datetime     null comment '创建日期',
    update_time datetime     null comment '更新时间'
)
    comment '本地存储' row_format = COMPACT;

INSERT INTO eladmin.tool_local_storage (storage_id, real_name, name, suffix, path, type, size, create_by, update_by, create_time, update_time) VALUES (10, '5zvmsspucxv5zvmsspucxv-20241004042427132.jpg', '照片1', 'jpg', 'C:\\eladmin\\file\\图片\\5zvmsspucxv5zvmsspucxv-20241004042427132.jpg', '图片', '1.49MB   ', 'admin', 'admin', '2024-10-04 16:24:27', '2024-10-04 16:24:27');
INSERT INTO eladmin.tool_local_storage (storage_id, real_name, name, suffix, path, type, size, create_by, update_by, create_time, update_time) VALUES (11, 'f3ll1hdeuvrf3ll1hdeuvr-2024100404262254.jpg', '照片2', 'jpg', 'C:\\eladmin\\file\\图片\\f3ll1hdeuvrf3ll1hdeuvr-2024100404262254.jpg', '图片', '1.47MB   ', 'admin', 'admin', '2024-10-04 16:26:22', '2024-10-04 16:26:22');
INSERT INTO eladmin.tool_local_storage (storage_id, real_name, name, suffix, path, type, size, create_by, update_by, create_time, update_time) VALUES (12, 'R-C-20241004044746694.jfif', '照片3', 'jfif', 'C:\\eladmin\\file\\其他\\R-C-20241004044746694.jfif', '其他', '561.17KB   ', 'admin', 'admin', '2024-10-04 16:47:46', '2024-10-04 16:47:46');
