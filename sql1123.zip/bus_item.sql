create table bus_item
(
    id           int auto_increment
        primary key,
    name         varchar(255)                            not null,
    price        decimal(10, 2)                          not null,
    quantity     int         default 0                   null,
    created_at   timestamp   default current_timestamp() null,
    updated_at   timestamp   default current_timestamp() null on update current_timestamp(),
    order_status varchar(50) default '0'                 not null
);

INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (1, 'Apple', 0.99, 100, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (2, 'Orange', 1.29, 150, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (3, 'Banana', 0.59, 200, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (4, 'Grapes', 2.99, 50, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (5, 'Watermelon', 5.99, 20, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (6, 'Strawberry', 3.49, 75, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (7, 'Blueberry', 4.49, 60, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (8, 'Peach', 2.59, 80, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (9, 'Mango', 1.99, 90, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (10, 'Pineapple111', 4.00, 30, '2024-10-03 16:56:57', '2024-10-08 15:46:23', '0');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (11, 'cocona', 12.50, 30, '2024-10-31 00:00:00', '2024-10-08 15:46:23', '4');
INSERT INTO eladmin.bus_item (id, name, price, quantity, created_at, updated_at, order_status) VALUES (12, '草莓', 20.50, 1001, '2024-10-02 00:00:00', '2024-10-16 00:00:00', '2');
