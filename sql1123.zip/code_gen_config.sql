create table code_gen_config
(
    config_id   bigint auto_increment comment 'ID'
        primary key,
    table_name  varchar(255) null comment '表名',
    author      varchar(255) null comment '作者',
    cover       bit          null comment '是否覆盖',
    module_name varchar(255) null comment '模块名称',
    pack        varchar(255) null comment '至于哪个包下',
    path        varchar(255) null comment '前端代码生成的路径',
    api_path    varchar(255) null comment '前端Api文件路径',
    prefix      varchar(255) null comment '表前缀',
    api_alias   varchar(255) null comment '接口名称'
)
    comment '代码生成器配置' row_format = COMPACT;

create index idx_table_name
    on code_gen_config (table_name(100));

INSERT INTO eladmin.code_gen_config (config_id, table_name, author, cover, module_name, pack, path, api_path, prefix, api_alias) VALUES (7, 'business_user', 'laozhao', false, 'eladmin-system', 'me.zhengjie.modules.business', 'D:\\Documents', 'D:\\Documents\\', 'business', '测试01');
INSERT INTO eladmin.code_gen_config (config_id, table_name, author, cover, module_name, pack, path, api_path, prefix, api_alias) VALUES (8, 'bus_item', 'laozhao', true, 'eladmin-system', 'me.zhengjie.demo', 'D:\\Documents\\views\\demo', 'D:\\Documents\\views\\demo\\', 'bus_', '测试商品');
INSERT INTO eladmin.code_gen_config (config_id, table_name, author, cover, module_name, pack, path, api_path, prefix, api_alias) VALUES (9, 'bus_emp', 'Laozhao', false, 'eladmin-system', 'me.zhengjie.business', 'src/views/business', 'src/views/business\\', 'bus_', '项目测试');
INSERT INTO eladmin.code_gen_config (config_id, table_name, author, cover, module_name, pack, path, api_path, prefix, api_alias) VALUES (10, 'bus_seller_info', 'Laozhao', false, 'eladmin-system', 'me.zhengjie.seller', 'D:\\Documents\\views', 'D:\\Documents\\views\\', 'bus_', '卖家测试');
INSERT INTO eladmin.code_gen_config (config_id, table_name, author, cover, module_name, pack, path, api_path, prefix, api_alias) VALUES (11, 'bus_order', 'LaoZhao', false, 'eladmin-system', 'me.zhengjie.order', 'D:\\Documents\\views', 'D:\\Documents\\views\\', 'bus_', '订单管理');
INSERT INTO eladmin.code_gen_config (config_id, table_name, author, cover, module_name, pack, path, api_path, prefix, api_alias) VALUES (12, 'bus_app_info', 'Laozhao', false, 'eladmin-system', 'me.zhengjie.appinfo', 'F:\\eladminView', 'F:\\eladminView\\', 'bus_', 'app账号管理');
INSERT INTO eladmin.code_gen_config (config_id, table_name, author, cover, module_name, pack, path, api_path, prefix, api_alias) VALUES (13, 'bus_finance_records', 'Laozhao', false, 'eladmin-system', 'me.zhengjie.finance', 'D:\\Documents\\views', 'D:\\Documents\\views\\', 'bus_', '财务管理');
