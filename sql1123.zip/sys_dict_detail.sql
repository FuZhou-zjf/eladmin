create table sys_dict_detail
(
    detail_id   bigint auto_increment comment 'ID'
        primary key,
    dict_id     bigint(11)   null comment '字典id',
    label       varchar(255) not null comment '字典标签',
    value       varchar(255) not null comment '字典值',
    dict_sort   int(5)       null comment '排序',
    create_by   varchar(255) null comment '创建者',
    update_by   varchar(255) null comment '更新者',
    create_time datetime     null comment '创建日期',
    update_time datetime     null comment '更新时间'
)
    comment '数据字典详情' row_format = COMPACT;

create index FK5tpkputc6d9nboxojdbgnpmyb
    on sys_dict_detail (dict_id);

INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (1, 1, '激活', 'true', 1, null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (2, 1, '禁用', 'false', 2, null, null, null, null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (3, 4, '启用', 'true', 1, null, null, null, null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (4, 4, '停用', 'false', 2, null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (5, 5, '启用', 'true', 1, null, null, null, null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (6, 5, '停用', 'false', 2, null, null, '2019-10-27 20:31:36', null);
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (10, 7, '已售 - 未收款', '2', 2, 'admin', 'admin', '2024-10-08 23:19:35', '2024-11-15 01:17:23');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (11, 7, '已售 - 已完成付款', '1', 1, 'admin', 'admin', '2024-10-08 23:20:11', '2024-11-15 01:17:13');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (12, 7, '已作废 - 账号已无效', '10', 10, 'admin', 'admin', '2024-10-08 23:21:37', '2024-11-15 01:19:28');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (13, 7, '正常状态 - 代售', '3', 3, 'admin', 'admin', '2024-10-08 23:22:13', '2024-11-15 01:17:36');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (14, 7, '问题状态 - 备注中有问题说明', '4', 4, 'admin', 'admin', '2024-10-08 23:22:40', '2024-11-15 01:17:54');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (15, 7, '待处理', '0', 0, 'admin', 'admin', '2024-10-08 23:38:57', '2024-10-08 23:40:33');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (20, 9, '待定', '0', 0, 'admin', 'admin', '2024-10-09 19:49:20', '2024-10-09 19:49:20');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (21, 9, '抖音', '1', 1, 'admin', 'admin', '2024-10-09 19:49:27', '2024-10-09 19:49:27');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (22, 9, '亚马逊', '2', 2, 'admin', 'admin', '2024-10-09 20:36:08', '2024-10-09 20:36:08');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (23, 9, 'eBay', '3', 3, 'admin', 'admin', '2024-10-09 20:36:20', '2024-10-09 20:36:20');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (24, 10, '销售提成', 'amount', 1, 'admin', 'admin', '2024-11-01 22:58:10', '2024-11-02 01:43:09');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (25, 10, '佣金', 'commission', 2, 'admin', 'admin', '2024-11-01 22:58:24', '2024-11-02 01:43:27');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (26, 10, '推荐费', 'referral_fee', 3, 'admin', 'admin', '2024-11-01 22:59:58', '2024-11-02 01:43:39');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (27, 11, '收入', 'income', 2, 'admin', 'admin', '2024-11-01 23:05:15', '2024-11-02 18:26:46');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (28, 11, '支出', 'expense', 1, 'admin', 'admin', '2024-11-01 23:05:42', '2024-11-02 18:26:31');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (29, 12, '员工', 'employee', 1, 'admin', 'admin', '2024-11-01 23:13:55', '2024-11-02 01:27:05');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (30, 12, '卖家', 'seller', 2, 'admin', 'admin', '2024-11-01 23:14:10', '2024-11-02 01:27:18');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (31, 12, '推荐人', 'referrer', 3, 'admin', 'admin', '2024-11-01 23:14:23', '2024-11-02 01:28:08');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (32, 13, '本地上传', 'local', 1, 'admin', 'admin', '2024-11-04 00:10:01', '2024-11-04 00:11:38');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (33, 13, '百度云盘', 'baiduYun', 2, 'admin', 'admin', '2024-11-04 00:10:43', '2024-11-04 00:11:35');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (34, 10, '预付款金额', 'pay_fee', 5, 'admin', 'admin', '2024-11-15 21:51:25', '2024-11-16 22:50:08');
INSERT INTO eladmin.sys_dict_detail (detail_id, dict_id, label, value, dict_sort, create_by, update_by, create_time, update_time) VALUES (35, 10, '收款金额', 'sale_fee', 4, 'admin', 'admin', '2024-11-15 21:52:45', '2024-11-15 21:52:45');
